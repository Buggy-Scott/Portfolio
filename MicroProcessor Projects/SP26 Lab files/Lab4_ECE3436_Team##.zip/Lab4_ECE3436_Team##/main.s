;****************** main.s ***************
; Program written by: Dr. D
; Date Created: 03/27/2023
; Last Modified:  
; Brief description of the program:
; 	Fall 2022 Lab 5
; 		PF0	-->	SW2
;		PF1	-->	Red LED
;		PF2	-->	Blue LED
;		PF3	--> Green LED
;		PF4	--> SW1


	THUMB
		
; Base address for Port F Data Register = 0x4002.5000

; *********************************************************************
; ************************* EQU DIRECTIVES ****************************
; *********************************************************************





	  
; *********************************************************************
; ************************* ROM CONSTANTS AREA ************************
; *********************************************************************
; Constants and code area starts at address 0x0000.0000
	AREA    MyConstants, DATA, READONLY, ALIGN=2		; Flash EEPROM


		 

		 
		 
; *********************************************************************
; ************************* RAM VARIABLES AREA ************************
; *********************************************************************
; SRAM variables area starts at address 0x2000.0000
	AREA    MyVariables, DATA, READWRITE, ALIGN=2		; SRAM



  
		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM


	EXPORT  Start
	IMPORT	PortF_Config
	


; MAIN PROGRAM ****************************
;	Port F has 5 pins.
; 		PF0	-->	SW2
;		PF1	-->	Red LED
;		PF2	-->	Blue LED
;		PF3	--> Green LED
;		PF4	--> SW1

Start
	BL	PortF_Config
	
;*********** Begin Coding Here **************
	

	



	
	
	
	


	NOP
      

	ALIGN        ; make sure the end of this section is aligned
	END          ; end of file