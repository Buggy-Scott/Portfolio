;****************** main.s ***************
; Program written by: Dr. D
; Date Created: 10/06/2021
; Last Modified:  
; Brief description of the program: GPIO Mini-lab to test I/O functionality on LaunchPad

; 	PF0	-->	SW2
;	PF1	-->	Red LED
;	PF2	-->	Blue LED
;	PF3	--> Green LED
;	PF4	--> SW1


	THUMB
		
; Base address for Port F Data Register = 0x4002.5000

;GPIO_PORTF_DATA_RED	EQU	0x40025008	; GPIO PF1 --> Red LED
;GPIO_PORTF_DATA_BLUE	EQU	0x40025010	; GPIO PF2 --> Blue LED
;GPIO_PORTF_DATA_GREEN	EQU	0x40025020	; GPIO PF3 --> Green LED



GPIO_PORTF_DATA_R  		EQU 0x400253FC	; GPIO Full Data Register for port F


	  
; *********************************************************************
; ************************* ROM CONSTANTS AREA ************************
; *********************************************************************
; Constants and code area starts at address 0x0000.0000
	AREA    MyConstants, DATA, READONLY, ALIGN=2		; Flash EEPROM


		 
	ALIGN
		 
		 
; *********************************************************************
; ************************* RAM VARIABLES AREA ************************
; *********************************************************************
; SRAM variables area starts at address 0x2000.0000
	AREA    MyVariables, DATA, READWRITE, ALIGN=2		; SRAM



	ALIGN		  
		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM
		  
		  
		  


	EXPORT  Start

	IMPORT	portFconfig
	


; MAIN PROGRAM ****************************
;	Port F has 5 pins.
; 		PF0	-->	SW2
;		PF1	-->	Red LED
;		PF2	-->	Blue LED
;		PF3	--> Green LED
;		PF4	--> SW1

Start

	BL	portFconfig

; ******************************
; START YOUR CODE HERE
; *****************************
loop






	
	B	loop





	NOP
      

	ALIGN        ; make sure the end of this section is aligned
	END          ; end of file