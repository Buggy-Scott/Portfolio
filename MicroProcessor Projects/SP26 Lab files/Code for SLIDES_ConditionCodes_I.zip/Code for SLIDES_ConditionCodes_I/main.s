;****************** main.s ***************
; Program written by: Dr. D
; Date Created: 9/1/20
; Last Modified: 9/2/20
; Brief description of the program: Condition code examples
;	
	  

	   THUMB	   
		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM
		  
		  
		  
	EXPORT  Start
		  




; ****************************************************************************
; ****************************************************************************
; ******************************** MAIN PROGRAM ******************************
; ****************************************************************************
; ****************************************************************************

Start

;********************* Example 1 **********************
; 0x10 + 0x1 = 0x11

	MOV32	R0, #0		; clear all flags
	ADDS	R0, R0, #1	

	MOV	R0, #0x10
	MOV	R1,	#0x1
	ADD R2, R0, R1		; does not set flags
	ADDS R2, R0, R1		; sets the flags
	
	NOP
	
	
;********************* Example 2 **********************
; 0 + 0 = 0

	MOV32	R0, #0		; clear all flags
	ADDS	R0, R0, #1	
	
	MOV	R0, #0x0		
	MOV	R1,	#0x0
	ADD	R2, R0, R1		; does not set flags
	ADDS R2, R0, R1		; sets the flags
	
	NOP
	
	
;********************* Example 3 **********************
; 1 + 1 = 2

	;MOV32	R0, #0		; clear all flags
	;ADDS	R0, R0, #1	
	
	MOV	R0, #0x1		
	MOV	R1,	#0x1
	ADD	R2, R0, R1		; does not set flags
	ADDS R2, R0, R1		; sets the flags
	
	NOP
	
		
;********************* Example 4 **********************
; 0 + 0xFFFF.FFFF = 0xFFFF.FFFF
; Unsigned --> 0 + 4,294,967,295 = 4,294,967,295

	MOV32	R0, #0		; clear all flags
	ADDS	R0, R0, #1	
	
	MOV	R0, #0x0		
	MOV32	R1,	#0xFFFFFFFF
	ADD	R2, R0, R1		; does not set flags
	ADDS R2, R0, R1		; sets the flags
	
	NOP


;********************* Example 5 - same as Example 1, but interpret numbers as 2's complement; does this change anything? **********************
; 0x10 + 0x1 = 0x11
; Unsigned --> 16 + 1 = 17		; is this correct?
; Signed --> 16 + 1 = 17		; is this correct?

	MOV32	R0, #0		; clear all flags
	ADDS	R0, R0, #1	

	MOV	R0, #0x10
	MOV	R1,	#0x1
	ADD R2, R0, R1		; does not set flags
	ADDS R2, R0, R1		; sets the flags
	
	NOP


;********************* Example 6 **********************
; 0x8000.0000 + 0x0000.0001 = 0x8000.0001
; Unsigned --> 2,147,483,648 + 1 = 2,147,483,649    * is this correct?
; Signed --> -2,147,483,648 + 1 = -2,147,483,647	* is this correct?

	MOV32	R0, #0		; clear all flags
	ADDS	R0, R0, #1	
	
	MOV32	R0, #0x80000000		
	MOV	R1,	#0x1
	ADD	R2, R0, R1		; does not set flags
	ADDS R2, R0, R1		; sets the flags
	
	NOP
		

;********************* Example 7 **********************
; 0xFFFF.FFFF + 0x0000.0001 = 0x0000.0000
; Unsigned --> 4,294,967,295 + 1 = 0    	* is this correct?
; Signed --> -1 + 1 = 0						* is this correct?

	MOV32	R0, #0		; clear all flags
	ADDS	R0, R0, #1	
	
	MOV32	R0, #0xFFFFFFFF		
	MOV	R1,	#0x1
	ADD	R2, R0, R1		; does not set flags
	ADDS R2, R0, R1		; sets the flags
	
	NOP
		

;********************* Example 8 **********************
; 0x7FFF.FFFF + 0x7FFFF.FFFF = 0xFFFF.FFFE
; Unsigned --> 2,147,483,647 + 2,147,483,647 = 4,294,967,294    	* is this correct?
; Signed --> 2,147,483,647 + 2,147,483,647 = -2						* is this correct?

	MOV32	R0, #0		; clear all flags
	ADDS	R0, R0, #1	
	
	MOV32	R0, #0x7FFFFFFF		
	MOV32	R1,	#0x7FFFFFFF
	ADD	R2, R0, R1		; does not set flags
	ADDS R2, R0, R1		; sets the flags
	
	NOP
		
		
;********************* Example 9 **********************
; 0x8000.0000 + 0x8000.0000 = 0x0000.0000
; Unsigned --> 2,147,483,648 + 2,147,483,648 = 0    	* is this correct?
; Signed --> (-2,147,483,648) + (-2,147,483,648) = 0	* is this correct?

	MOV32	R0, #0		; clear all flags
	ADDS	R0, R0, #1	
	
	MOV32	R0, #0x80000000		
	MOV32	R1,	#0x80000000
	ADD	R2, R0, R1		; does not set flags
	ADDS R2, R0, R1		; sets the flags
		
	NOP
	

      
    ALIGN      ; make sure the end of this section is aligned
    END        ; end of file

