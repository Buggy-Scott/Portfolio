
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'ECE_3436_Condition_Codes_I' 
 * Target:  'ECE_3436_Condition_Codes_I' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "TM4C123.h"



#endif /* RTE_COMPONENTS_H */
