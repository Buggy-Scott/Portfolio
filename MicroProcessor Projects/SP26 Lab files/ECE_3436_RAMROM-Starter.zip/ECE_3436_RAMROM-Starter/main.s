;****************** main.s ***************
; Program written by:        ***Your Names**update this***
; Date Created: 
; Last Modified: 
; Brief description of the program:
;	

		  

	THUMB
		   

 
 

		 
		 

		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
; ROM addresses start at address 0x0000.0000, but your code starts a little after that
	AREA    |.text|, CODE, READONLY, ALIGN=2			; Flash EEPROM
		  
		  
	EXPORT  Start



; **************************** MAIN PROGRAM **************************

Start







	







	


    
    ALIGN      ; make sure the end of this section is aligned
    END        ; end of file

