;****************** main.s ***************
; Program written by:        ***Your Names**update this***
; Date Created: 
; Last Modified: 
; Brief description of the program:
;	

		  

	THUMB
		   

 
 
; *********************************************************************
; ************************* ROM CONSTANTS AREA ************************
; *********************************************************************
; Constants and code area starts at address 0x0000.0000
	AREA    MyConstants, DATA, READONLY, ALIGN=2		; Flash EEPROM


		 
	ALIGN
		 
		 
; *********************************************************************
; ************************* RAM VARIABLES AREA ************************
; *********************************************************************
; SRAM variables area starts at address 0x2000.0000
	AREA    MyVariables, DATA, READWRITE, ALIGN=2		; SRAM


	
	ALIGN
		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
; ROM addresses start at address 0x0000.0000, but your code starts a little after that
	AREA    |.text|, CODE, READONLY, ALIGN=2			; Flash EEPROM
		  
		  

		  
	EXPORT  Start
		  
Start



; ****************************************************************************
; ****************************************************************************
; ******************************** MAIN PROGRAM ******************************
; ****************************************************************************
; ****************************************************************************


	NOP
	
; ********** TASK 1 **********
; decimal notation



; ********** TASK 2 **********
; hexadecimal notation



; ********** TASK 3 **********
; binary notation


	
; BONUS: load -1 in all notations



; ********** TASK 4 **********
; addition

	
; subtraction

	
; multiplication

	
; division



; ********** TASK 5 **********
; R1 = 3
; R2 = 5
; R3 = 2
; R0 = (R1 + R2)*R3-R1 = (3+5)*2-3 = 13
; first load registers, then solve equation



	
; ********** TASK 6 **********
; R0 = (R1 + R2)*R3-10 = (3+5)*2-10 = 6
; first load registers (if needed), then solve equation

	
	
	
; ********** TASK 7 **********
; R0 = (R1 + R2)*R3-myNum = 6
; first load registers (if needed), then solve equation

	
	
	
; ********** TASK 8 **********




; ********** TASK 9 **********

	


; ********** TASK 10 **********
;	R0 = VS = 300 [V]
;	R1 = RES1 = 100 [OHMS]
;	R2 = RES2 = 50 [OHMS]
;	R3 = REQ
;	R4 = IS
;	R5 = V1
;	R6 = V2






	
	NOP

    
    ALIGN      ; make sure the end of this section is aligned
    END        ; end of file

