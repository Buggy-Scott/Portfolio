	THUMB						;

StackSize	EQU		0x00000100	;
	
	AREA STACK, NOINIT, READWRITE, ALIGN=3
MyStackMem	SPACE	StackSize
	
	AREA	RESET, READONLY
	EXPORT	__Vectors
__Vectors
	DCD MyStackMem + StackSize
	DCD Reset_Handler

	AREA	MYCODE, CODE, READONLY
	ENTRY
	EXPORT	Reset_Handler

Reset_Handler

	MOV	R0, #0
	MOV R1, #16	
	MOV R2, #8
	
	MOV R3, R2
	
lbegin
	CBZ	R3, lend
	ADD	R0, R1
	;ADD	R1, #2
	SUB	R3, #1
	B	lbegin
lend
	END