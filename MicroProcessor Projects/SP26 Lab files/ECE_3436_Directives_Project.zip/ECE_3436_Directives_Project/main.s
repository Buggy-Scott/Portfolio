;****************** main.s ***************
; Program written by:        ***Your Names**update this***
; Date Created: 
; Last Modified: 
; Brief description of the program:
;	

		  

	THUMB
		   
 
; *********************************************************************
; ************************* ROM CONSTANTS AREA ************************
; *********************************************************************
; Constants and code area starts at address 0x0000.0000
	AREA    MyConstants, DATA, READONLY, ALIGN=2		; Flash EEPROM

myConst1	DCD		0x12345678
myConst2	DCD		0xABCDEF09
		 

		 
		 
; *********************************************************************
; ************************* RAM VARIABLES AREA ************************
; *********************************************************************
; SRAM variables area starts at address 0x2000.0000
	AREA    MyVariables, DATA, READWRITE, ALIGN=2		; SRAM

myVar1		SPACE	2
myVar2		SPACE	2

	
		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
; ROM addresses start at address 0x0000.0000, but your code starts a little after that
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM
		  
		  

		  
	EXPORT  Start
		  

; ****************************************************************************
; ******************************** MAIN PROGRAM ******************************
; ****************************************************************************
Start


	NOP		; *only* instruction in this file
	NOP
	NOP
	NOP


	
;*********************** END SUBROUTINES ****************************
      
    ALIGN      ; make sure the end of this section is aligned
    END        ; end of file

