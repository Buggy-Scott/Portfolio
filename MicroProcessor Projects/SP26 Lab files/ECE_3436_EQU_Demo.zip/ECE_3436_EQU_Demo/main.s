;****************** main.s ***************
; Program written by:        ***Your Names**update this***
; Date Created: 
; Last Modified: 
; Brief description of the program:
;	

		  

	   THUMB
		   
 
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM
		  
		  

		  
	EXPORT  Start
	

INITIAL		EQU		0x10	; hex 10
CHARGE1		EQU		4		; decimal 4
CHARGE2		EQU		0x5		; hex 5
DEPOSIT		EQU		2_11	; binary 3
PASSWORD	EQU		0x12345678


; ****************************************************************************
; ******************************** MAIN PROGRAM ******************************
; ****************************************************************************
Start


; ********** VERSION 1 **********
	MOV R0, #0x10	
	MOV	R1, #4	
	MOV	R2, #0x5	
	MOV	R3,	#2_11	
	
	SUB	R4, R0, R1		; subtract the first charge from the initial balance
	SUB	R4,	R4,	R2		; subtract the second charge from the balance
	ADD	R4, R4, R3		; add the deposit to the balance
	; R4 now has my ending balance
	
	MOV32 R5, #0x12345678
	
	NOP
	
	
	
; ********** VERSION 2 **********

	MOV R0, #INITIAL	; becomes --> MOV R0, #0x10
	MOV	R1, #CHARGE1	; becomes --> MOV R1, #4
	MOV	R2, #CHARGE2	; becomes --> MOV R2, #0x5
	MOV	R3,	#DEPOSIT	; becomes --> MOV R3, #2_11

	SUB	R4, R0, R1		; subtract the first charge from the initial balance
	SUB	R4,	R4,	R2		; subtract the second charge from the balance
	ADD	R4, R4, R3		; add the deposit to the balance
	; R4 now has my ending balance
	
	MOV32 R5, #PASSWORD	; becomes --> MOVW R5, #0x5678; MOVT R5, #0x1234
	
	NOP
	
	

; ********** VERSION 3 **********
	MOV	R0, #INITIAL	; becomes --> MOV R0, #0x10
	
	SUB	R4, R0, #CHARGE1	; subtract the first charge from the initial balance
	SUB	R4,	R4,	#CHARGE2	; subtract the second charge from the balance
	ADD	R4, R4, #DEPOSIT	; add the deposit to the balance
	; R4 now has my ending balance

	MOV32 R5, #PASSWORD	; becomes --> MOVT
	
	NOP


; try some other operations on your own

	
	

      
    ALIGN      ; make sure the end of this section is aligned
    END        ; end of file

