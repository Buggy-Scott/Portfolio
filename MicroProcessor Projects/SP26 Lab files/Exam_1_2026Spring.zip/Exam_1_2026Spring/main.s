;****************** main.s ***************
; Program written by: Dr. D
; Revised by Jianfeng Zheng
; Date Created: 09/22/2021
; Last Modified: 02/10/2026 


;===== Info ====
; Name: ANAYA SCOTT
; UHID: 1599670
;===============

	   THUMB
		   
; ************************************************
; ******************** TASK 0 ********************

		  

VSRC1 EQU 60;
VSRC2 EQU 9;
RIS0 EQU 12;
RIS1 EQU 12;
RIS2 EQU 3;
RIS3 EQU 6;
			
			
		
; *********************************************************************
; ************************* ROM CONSTANTS AREA ************************
; *********************************************************************
; Constants and code area starts at address 0x0000.0000
	AREA    MyConstants, DATA, READONLY, ALIGN=2		; Flash EEPROM
		 
	ALIGN
		 
; *********************************************************************
; ************************* RAM VARIABLES AREA ************************
; *********************************************************************
; SRAM variables area starts at address 0x2000.0000
	AREA    MyVariables, DATA, READWRITE, ALIGN=2		; SRAM

	ALIGN		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
	
; ************************************************
; ******************** TASK 1 ********************

	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash EEPROM
		 
	EXPORT Start
		

		
Start
	

; ************************************************
; ******************** TASK 2 ********************

	MOV R0, #RIS0
	MOV R1, #RIS1
	MOV R2, #RIS2
	MOV R3, #RIS3
	
	
; ************************************************
; ******************** TASK 3 ********************
; Ask the staff to check after this task
	MOV R6,#VSRC1;
	UDIV R6,R6,R0;
	NOP
	
	MUL R4,R0,R1
	ADD R5,R0,R1
	UDIV R4,R4,R5
	

; ************************************************
; ******************** TASK 4 ********************
	MOV R7, #VSRC2
	UDIV R7,R7,R2
	
	MUL R5, R2,R3
	ADD R8,R2,R3
	UDIV R5,R5,R8
	

; ************************************************
; ******************** TASK 5 ********************

	ADD R8,R6,R7
	MUL R9,R8,R5

; ************************************************
; ******************** TASK 6 ********************

	ADD R10, R5,R3
	UDIV R10, R9,R10
	
	MUL R11, R10,R3
	


; ************************************************
; ******************** TASK 7 ********************
; Change your EQU statement to make VSRC1 = 120 and VSRC2 = 18
; Check to see that your answers are still correct
; after this change. Demonstrate to the staff that
; your code works with both values in the EQU
; statement.


	NOP
	NOP
	NOP
	NOP
	


      ALIGN        ; make sure the end of this section is aligned
      END          ; end of file