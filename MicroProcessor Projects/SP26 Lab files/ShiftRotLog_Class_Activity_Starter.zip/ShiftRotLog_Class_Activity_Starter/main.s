;****************** main.s ***************
; Program written by: Dr. D
; Date Created: 02/04/2021
; Last Modified: 09/26/2023 
; Brief description of the program
; The objective of this program is to ...
;	demonstrate the use of shift & rotate instructions
;	as well as to demonstrate how shifts may be used
;	as signed and unsigned division.


 ; Practice with shifts
	; use this site as a reference
	; http://www.keil.com/support/man/docs/armasm/armasm_dom1361289852998.htm 
	; Debug all of your code using the simulator and making use of breakpoints
	; as well as the step function.


      
	   THUMB
		    
		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM
		  
		  
	ALIGN
		  
	EXPORT  Start

BITSTRING1	EQU	0xFF00FF00
BITSTRING2	EQU	0x00FF00FF
BITSTRING3	EQU	0xABCDEF12
BITSTRING4	EQU	0xFFFFFFFF


Start

	MOV		R0, #0
	ADDS 	R0, #0x1	; this code clears the condition flags
	
	; sample strings to play with
	MOV32 	R1, #BITSTRING1		
	MOV32	R2,	#BITSTRING2
	MOV32	R3, #BITSTRING3
	MOV32	R4, #BITSTRING4



; **********************************************************
; ******************** Shift Operations ********************
; **********************************************************


; ******************** Logical Shift Right (LSR) --> updates N,Z,C when S is used ********************
; b0 --> shifts right into the Carry bit
;R1 = 0xFF00FF00
;R2 = 0x00FF00FF
;R3	= 0xABCDEF12
;R4 = 0xFFFFFFFF
	; shift w/o updating flags
	LSR	R0, R1, #4			; N = _____, Z = _____, C = _____, V = _____
	LSR	R0, R0, #2			; N = _____, Z = _____, C = _____, V = _____
	LSR	R0, R0, #1			; N = _____, Z = _____, C = _____, V = _____
	LSR	R0, R3, #16			; N = _____, Z = _____, C = _____, V = _____
	MOV	R5, #3				; N = _____, Z = _____, C = _____, V = _____
	LSR	R0, R4, R5			; N = _____, Z = _____, C = _____, V = _____
	NOP
	

	; shift w/updating flags N,Z,&C  (V is not updated)
;R1 = 0xFF00FF00
;R2 = 0x00FF00FF
;R3	= 0xABCDEF12
;R4 = 0xFFFFFFFF
	LSRS	R0, R1, #8			; N = _____, Z = _____, C = _____, V = _____
	LSRS	R0, R0, #1			; N = _____, Z = _____, C = _____, V = _____
	LSRS	R5, R4, #32			; N = _____, Z = _____, C = _____, V = _____
	MOV		R0, #16				; N = _____, Z = _____, C = _____, V = _____
	LSRS	R6, R3, R0			; N = _____, Z = _____, C = _____, V = _____
	NOP
	
	
	; unsigned division w/LSR
;R1 = 0xFF00FF00
;R2 = 0x00FF00FF
;R3	= 0xABCDEF12
;R4 = 0xFFFFFFFF
	MOV	R2, #64						; N = _____, Z = _____, C = _____, V = _____
	LSR	R2, #1	; divide by 2		; N = _____, Z = _____, C = _____, V = _____
	LSR	R2,	#2	; divide by 4		; N = _____, Z = _____, C = _____, V = _____
	LSR	R2, #3	; divide by 8		; N = _____, Z = _____, C = _____, V = _____
	
	LSR	R2, #1	; divide by 2, fraction remainder 			; N = _____, Z = _____, C = _____, V = _____
	NOP
	


	; clear all flags
	MOV		R0, #0				; N = _____, Z = _____, C = _____, V = _____
	ADDS	R0, #1				; N = _____, Z = _____, C = _____, V = _____
	
	
	
	; ***************************
	; ***** COMPLETE TASK 1 *****
	; ***************************
	
	

; ******************** Arithmetic Shift Right --> updates N,Z,C when S is used ********************

	; clear all flags
	MOV		R0, #0			; N = _____, Z = _____, C = _____, V = _____
	ADDS	R0, #1			; N = _____, Z = _____, C = _____, V = _____


	; shift w/o updating flags
	ASR	R2, R1, #4			; N = _____, Z = _____, C = _____, V = _____
	ASR	R4, R3, #16			; N = _____, Z = _____, C = _____, V = _____
	ASR	R6, R5, R0			; N = _____, Z = _____, C = _____, V = _____
	

	; shift w/updating flags
	MOV32 R2, #0x80000008	; N = _____, Z = _____, C = _____, V = _____
	ASRS R2, R2, #1			; N = _____, Z = _____, C = _____, V = _____
	ASRS R2, R2, #1			; N = _____, Z = _____, C = _____, V = _____
	ASRS R2, R2, #1			; N = _____, Z = _____, C = _____, V = _____
	ASRS R2, R2, #1			; N = _____, Z = _____, C = _____, V = _____
	
	MOV32 R4, #0x40000004	; N = _____, Z = _____, C = _____, V = _____
	ASRS R4, R4, #1			; N = _____, Z = _____, C = _____, V = _____
	ASRS R4, R4, #1			; N = _____, Z = _____, C = _____, V = _____
	ASRS R4, R4, #1			; N = _____, Z = _____, C = _____, V = _____
	ASRS R4, R4, #1			; N = _____, Z = _____, C = _____, V = _____
	
	ASRS	R2, R1, #3		; N = _____, Z = _____, C = _____, V = _____
	ASRS	R6, R5, #32		; N = _____, Z = _____, C = _____, V = _____
	ASRS	R4, R5, R0		; N = _____, Z = _____, C = _____, V = _____
	
	NOP
	
		
	; signed division w/LSR
	MOV	R2, #-64	; -64 = 0xFFFF.FFC0					; N = _____, Z = _____, C = _____, V = _____
	ASR	R2, #1	; divide by 2, -32 = 0xFFFF.FFE0		; N = _____, Z = _____, C = _____, V = _____
	ASR	R2,	#2	; divide by 4, -8 = 0xFFFF.FFF8			; N = _____, Z = _____, C = _____, V = _____
	ASR	R2, #3	; divide by 8, -1 = 0xFFFF.FFFF			; N = _____, Z = _____, C = _____, V = _____
	
	ASR	R2, #1	; divide by 2							; N = _____, Z = _____, C = _____, V = _____
	
	NOP
	
	
	; ********************************
	; ***** COMPLETE TASKS 2 & 3 *****
	; ********************************
	
	
	
	
; ******************** Logical Shift Left (LSL) --> updates N,Z,C when S is used ********************

	; reset carry bit  (and others)
	MOV		R0, #0			; N = _____, Z = _____, C = _____, V = _____
	ADDS	R0, #1			; N = _____, Z = _____, C = _____, V = _____
	
	
	; shift w/o updating flags
	LSL	R2, R1, #4			; N = _____, Z = _____, C = _____, V = _____
	LSL	R4, R3, #16			; N = _____, Z = _____, C = _____, V = _____
	LSL	R6, R5, R0			; N = _____, Z = _____, C = _____, V = _____
	NOP
	

	; shift w/updating flags
	LSLS	R2, R1, #3		; N = _____, Z = _____, C = _____, V = _____
	LSLS	R4, R3, #31		; N = _____, Z = _____, C = _____, V = _____
	LSLS	R6, R5, R0		; N = _____, Z = _____, C = _____, V = _____
	NOP
	

	; unsigned multiplication w/LSR
	MOV	R2, #1											; N = _____, Z = _____, C = _____, V = _____
	LSL	R2, #1	; multiply by 2							; N = _____, Z = _____, C = _____, V = _____
	LSL	R2,	#2	; multiply by 4							; N = _____, Z = _____, C = _____, V = _____
	LSL	R2, #3	; multiply by 8		64 = 0x0000.0040	; N = _____, Z = _____, C = _____, V = _____
	NOP
	
	MOV32 R2, #0xFFFFFFFF					; N = _____, Z = _____, C = _____, V = _____
	LSLS  R2, #1	; multiply by 2			; N = _____, Z = _____, C = _____, V = _____
	NOP


	; signed multiplication w/LSR
	MOV	R2, #-1												; N = _____, Z = _____, C = _____, V = _____
	LSL	R2, #1	; multiply by 2		-02 = 0xFFFF.FFFE		; N = _____, Z = _____, C = _____, V = _____
	LSL	R2,	#2	; multiply by 4		-04 = 0xFFFF.FFF8		; N = _____, Z = _____, C = _____, V = _____
	LSL	R2, #3	; multiply by 8		-64 = 0xFFFF.FFC0		; N = _____, Z = _____, C = _____, V = _____
	NOP
	
	MOV32 R2, #0xFFFFFFFF					; N = _____, Z = _____, C = _____, V = _____
	LSLS  R2, #1	; multiply by 2			; N = _____, Z = _____, C = _____, V = _____
	NOP



	; ********************************
	; ***** COMPLETE TASKS 4 & 5 *****
	; ********************************



; ******************** Rotate Right (ROR) --> updates N,Z,C when S is used ********************
; b0 --> shifts right into Carry bit...AND rotates around to b31
; Carry bit = b31 after operation

	; reset carry bit  (and others)
	MOV		R0, #0			; N = _____, Z = _____, C = _____, V = _____
	ADDS	R0, #1			; N = _____, Z = _____, C = _____, V = _____



; BITSTRING2 = 0x00FF00FF

	MOV32	R2, #BITSTRING2				; N = _____, Z = _____, C = _____, V = _____
	RORS	R3, R2, #1					; N = _____, Z = _____, C = _____, V = _____
	RORS	R4, R3, R0					; N = _____, Z = _____, C = _____, V = _____
	NOP


	; ***************************
	; ***** COMPLETE TASK 6 *****
	; ***************************



; ******************** Rotate Right Once w/Extend --> updates N,Z,C when S is used ********************
; (RRX, uses the Carry bit as part of the loop)
; b0 --> shifts into Carry bit
; Carry bit --> rotates around into b31

	; reset carry bit  (and others)
	MOV		R0, #0			; N = _____, Z = _____, C = _____, V = _____
	ADDS	R0, #1			; N = _____, Z = _____, C = _____, V = _____
	
; BITSTRING2 = 0x00FF00FF
	MOV32 	R5, #BITSTRING2	; N = _____, Z = _____, C = _____, V = _____
	RRXS	R6, R5	; cannot use 2 operands with RRX ; N = _____, Z = _____, C = _____, V = _____
	RRXS	R7, R6			; N = _____, Z = _____, C = _____, V = _____
	NOP
	

	; ***************************
	; ***** COMPLETE TASK 7 *****
	; ***************************



; ******************************************************************
; ************************** TASKS *********************************
; ******************************************************************

	; TASK 1A: Load R7 with the decimal value 7.
	;		Divide R7 by 2 using a shift operation and place the result in R8. (do not set flags)
	;		Divide R7 by 2 using an unsigned divide instruction and place the result in R9. (unsigned divide) 
	;		Do you get the same result? Is the result correct?



	
	; TASK 1B: Load R7 with any 32-bit number. 
	;		Clear the flags.
	;		Use a shift operation and the condition flags to determine if the number is odd or even.
	


	

	; TASK 1 BONUS: Load R7 with any 32-bit number. 
	;		Clear the flags.
	;		Use a right shift operation and the condition flags to determine 
	;		how many 1s are in the binary number.
	;		Create an infinite loop for now. (We'll learn how to stop loops soon!)
	;		Hint: there is an ADC instruction that adds with the carry




	
	; TASK 2: Shift the bits in R5 to the right 5 times while setting the flags.
	;		Preserve the sign of the number.
	;		Place the result in register R6.
	;		What are the values of the condition flags after this operation? Why?
	
	
	
	
	
	; TASK 3: Load R7 with the decimal value -8.
	;		Divide R7 by 4 using a shift operation and place the result in R8.
	;		Divide R7 by 4 using a signed divide instruction and place the result in R9.
	;		Do you get the same result? Is the result correct?


	
	
	
	; TASK 4: Reset the value in R0 to 1 if needed.
	;		Shift the bits in R0 to the left 31 times while setting the flags.
	;		Place the result in register R2.
	;		What are the values of the condition flags after this operation? Why?
	



	; TASK 5: Load R7 with the decimal value 3.
	;		Multiply R7 by 4 using a shift operation and place the result in R8.
	;		Multiply R7 by 4 using a multiply instruction and place the result in R9.
	;		Do you get the same result? Is the result correct?
	



	; TASK 6: Rotate the bits in R2 once to the right while setting the flags.
	;		Place the result in R3.
	;		What is the result in R3? What flags are set and why?





	; TASK 7: rotate the bits in R0+Carry to the right 5 times
	;		Place the result in R7.
	;		What is the result in R7? What flags are set?






	

      ALIGN        ; make sure the end of this section is aligned
      END          ; end of file