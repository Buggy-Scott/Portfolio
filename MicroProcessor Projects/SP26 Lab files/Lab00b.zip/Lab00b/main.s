;****************** main.s ***************

	THUMB
		
; Constants and code area starts at address 0x0000.0000
	AREA    MyConstants, DATA, READONLY	; Flash EEPROM

SYSCTL_RCGCGPI0_R		EQU		0x400FE608
GPIO_PORTF_DATA_R		EQU		0x40025020
GPIO_PORTF_DIR_R		EQU		0x40025400
GPIO_PORTF_AFSEL_R		EQU		0x40025420
GPIO_PORTF_DEN_R		EQU		0x4002551C
	
GPIO_PORTF_CLK_EN		EQU		0x20
GPIO_PORTF_PIN3_EN		EQU		0x08
SYSTEM_CLOCK_FREQUENCY	EQU		16000000
DELAY_VALUE				EQU		SYSTEM_CLOCK_FREQUENCY/8
GPIO_PORTF_PIN3			EQU		0x08

		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM
	ENTRY
	EXPORT  Start
Start
	LDR		R1,	=SYSCTL_RCGCGPI0_R
	LDR		R0, [R1]
	ORR		R0, R0, #GPIO_PORTF_CLK_EN
	STR		R0,	[R1]
	
	NOP
	NOP
	NOP
	
	LDR		R1,	=GPIO_PORTF_DIR_R
	LDR		R0, [R1]
	ORR		R0, R0, #GPIO_PORTF_PIN3
	STR		R0,	[R1]	
	
	LDR		R1,	=GPIO_PORTF_DEN_R
	LDR		R0, [R1]
	ORR		R0, R0, #GPIO_PORTF_PIN3
	STR		R0,	[R1]

	LDR		R1,	=GPIO_PORTF_DATA_R

LED_Flash
	LDR		R0, [R1]
	EOR		R0, R0, #GPIO_PORTF_PIN3
	STR		R0,	[R1]
	
	LDR		R5,	=DELAY_VALUE
Delay
	SUBS	R5,	#1
	BNE		Delay
	B		LED_Flash

     

	ALIGN        ; make sure the end of this section is aligned
	END          ; end of file