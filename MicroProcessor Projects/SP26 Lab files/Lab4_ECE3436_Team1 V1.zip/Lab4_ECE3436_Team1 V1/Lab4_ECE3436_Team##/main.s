;****************** main.s ***************
; Program written by: Dr. D
; Date Created: 03/27/2023
; Last Modified:  
; Brief description of the program:
; 	Fall 2022 Lab 5
; 		PF0	-->	SW2
;		PF1	-->	Red LED
;		PF2	-->	Blue LED
;		PF3	--> Green LED
;		PF4	--> SW1



	THUMB
		
; Base address for Port F Data Register = 0x4002.5000

; *********************************************************************
; ************************* EQU DIRECTIVES ****************************
; *********************************************************************
 GPIO_PORTF_DATA_R EQU 0x400253FC
	
;LED MASKS
RED_MASK	EQU 0x02 ;PF1
BLUE_MASK	EQU 0x04 ;PF2
GREEN_MASK	EQU 0x08 ;PF3
ALL_LEDS_MASK	EQU 0x0E ;PF123
	
;SWITTCH MASKS
SW1_MASK 	EQU 0x10 ; PF4 WILL BE FOR SW1 MAKING IT AN ACTIVE LOW
SW2_MASK 	EQU 0x01 ; PF0 WILL BE FOR SW2 MAKING IN AN ACTIVE LOW
	
; STATE DEFINTIONS THIS WILL ALLOW FOR THE BLINKING EFFECTS ON THE LED
STATE_IDLE 	EQU 0	;ALL LED WILL BE OFF
STATE_RED	EQU 1	;RED LED BLINKS IN 2s PERIOD
STATE_BLUE	EQU 2	;BLUE LED BLINKS IN 1s PERIOD
STATE_GREEN	EQU 3	;GREEN LED BLINKS IN 0.5s PERIOD
	
	; UNDERSTAND TTHAT THE DELAY COUNTS FOR 16MHz FOR A STANDARD CLOCK 
	; WE MIGHT HAVE TO ADJUST THESE VALUES TO FINE TURN THE LAUNCHPAD
DELAY_250MS 	EQU 4000000 ;0.25s FOR THE GREEN LED HALF PERIOD 

DELAY_500MS 	EQU 8000000 ;0.5s FOR THE BLUE LED HALF PERIOD


DELAY_1SEC 		EQU 1600000 ; 1 FOR THE RED LED HALF PERIOD
	
	
  
; *********************************************************************
; ************************* ROM CONSTANTS AREA ************************
; *********************************************************************
; Constants and code area starts at address 0x0000.0000
	AREA    MyConstants, DATA, READONLY, ALIGN=2		; Flash EEPROM


		 

		 
		 
; *********************************************************************
; ************************* RAM VARIABLES AREA ************************
; *********************************************************************
; SRAM variables area starts at address 0x2000.0000
	AREA    MyVariables, DATA, READWRITE, ALIGN=2		; SRAM



 CURRENT_STATE 	SPACE 4 ; STORE CURRENT STATE  OF  0,1,2,3
		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM


	EXPORT  Start
	IMPORT	PortF_Config
	


; MAIN PROGRAM ****************************
;	Port F has 5 pins.
; 		PF0	-->	SW2
;		PF1	-->	Red LED
;		PF2	-->	Blue LED
;		PF3	--> Green LED
;		PF4	--> SW1

Start
	BL	PortF_Config
	
;*********** Begin Coding Here **************
	
;FIRST I THINK WE TO SET UP THE IDLE STATE
	LDR R0, =CURRENT_STATE
	MOV R1, #STATE_IDLE
	STR R1,[R0]
	
; THIS WILL TURN OFF THE LED INITIALLY
	LDR R0,=GPIO_PORTF_DATA_R
	MOV R1,#0
	STR R1,[R0]
	
MainLoop
	;THIS WILL READ THE CURRENT STATE FROM MEMEORY
	LDR R5, =CURRENT_STATE
	LDR R4,[R5] ;R4 WILL HOLD THE CURRENT STATE
	
	;THIS WILL READ THE SWITCHES
	LDR R0, =GPIO_PORTF_DATA_R
	LDR R1,[R0] ;R1 WILL BE THE CURRENT PORT F PIN VALUES
	
	; THIS WILL CHECK SW1, THEN GOES IDEL WHEN PRESSED
	LDR R2,=SW1_MASK
	TST R1,R2
	BEQ PressSW1
	
	;THIS WILL CHECK SW2,, THEN CYCLES THE STATES WHEN PRESSED
	LDR R2, =SW2_MASK
	TST R1,R2
	BEQ PressSW2
	
	;THIS WILL EXCUTE WHEN NO BUTTONS ARE NOT PRESSED
	CMP R4, #STATE_IDLE
	BEQ State_Idle
	
	CMP R4, #STATE_RED
	BEQ State_Red
	
	CMP R4,#STATE_BLUE
	BEQ State_Blue
	
	CMP R4,#STATE_GREEN
	BEQ State_Green
	
	B MainLoop ; WE SHOULD NEVER GET HERE
	
;WE ARE GONNA NEED SOME HANDLERS TO HELP US KNOW WHEN WE ARE IN THE STATE FOR THE BLOINKING,
; WHEN THE BUTTON IS PRRERSSED AND THE POSSIBLE SUBROUTINUES FOR THE CYCLES

;=====================================================
;STATE HANDLERS
;=====================================================

State_Idle
	;TURNS OFF ALL OF THE LEDS
	LDR R0, =gPIO_PORTF_DATA_R
	MOV R1,#0
	STR R1,[R0]
	B MainLoop
	
State_Red
	;THE LED WILL BLINK IN 2s PERIOD( 1 ON, 1 OFF)
	LDR R0, =GPIO_PORTF_DATA_R
	
	LDR R1, =RED_MASK
	STR R1, [R0]
	BL Delay_1sec
	
	;TURNS THE RED LED OFF
	MOV R1,#0
	STR R1,[R0]
	BL Delay_1sec
	
	B MainLoop
;----------------------------------------------------------	
State_Blue
	;THE LED WILL BLINK IN 1s PERIOD( 0.5 ON, 0.5 OFF)
	LDR R0, =GPIO_PORTF_DATA_R
	
	LDR R1, =BLUE_MASK
	STR R1, [R0]
	BL Delay_500ms
	
	;TURNS THE BLUE LED OFF
	MOV R1,#0
	STR R1,[R0]
	BL Delay_500ms
	
	B MainLoop
;--------------------------------------------------------
State_Green
	;THE LED WILL BLINK IN 0.5s PERIOD( 0.25 ON, 0.25 OFF)
	LDR R0, =GPIO_PORTF_DATA_R
	
	LDR R1, =GREEN_MASK
	STR R1, [R0]
	BL Delay_250ms
	
	;TURNS THE GREEN LED OFF
	MOV R1,#0
	STR R1,[R0]
	BL Delay_250ms
	
	B MainLoop
;========================================================
; BUTTON PRESS HANDLER
;========================================================
;THIS WILL CHECK WHEN SW1 IS PRESSED AND GOES INTO IDLE STATE
PressSW1
	LDR R5,=CURRENT_STATE
	MOV R1,#STATE_IDLE
	STR R1,[R0]
	
	;TURNS OFF ALL THE LED IMMEDIATELY
	LDR R0, =GPIO_PORTF_DATA_R
	MOV R1,#0
	STR R1, [R0]
	
	; THIS WILL CHECK TO WAIT FOR SW1 TO BE RELEASED
SW1_WaitReleases
	LDR R0, =GPIO_PORTF_DATA_R
	LDR R1,[R0]
	LDR R2, =SW1_MASK
	TST R1,R2
	BEQ SW1_WaitRelease ; THIS IS WHEN THE BUTTON IS STILL PRESSED, KEEP WAITING
	
	B MainLoop
;-------------------------------------------------------




	
	
	
	


	NOP
      

	ALIGN        ; make sure the end of this section is aligned
	END          ; end of file