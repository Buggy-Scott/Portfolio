.\main.o: main.s
