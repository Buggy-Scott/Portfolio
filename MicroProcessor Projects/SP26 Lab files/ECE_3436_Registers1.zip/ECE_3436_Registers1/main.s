;****************** main.s ***************
; Author: Dr. D
; Date Created: 1/15/2018 
; Last Modified: 8/29/2023 
;
; Brief description of the program: Simple Program Class Demo
; 		Introduction to LaunchPad data storage
;
; Hardware connections: 
;		no I/O
;
; Overall goal: 
;   	Test loading and storing data in registers 
;
; The specific operation of this system:
;   	write/read registers

	

    THUMB		; use Thumb instruction set
		  
		  
		  
; *********************************************************************
; *************************** CODE AREA *******************************
; *********************************************************************
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM
; CODE area in ROM begins at 0x00000284
		  
		  
	EXPORT  Start
		
 
Start		; start executing here	
	
; TASK 1: 
;	Load registers 1-4 with numbers greater than 9 using the decimal format.
;	Load registers 5-8 with the same numbers using the hexadecimal format.
;	Load registers 9-12 with the same numbers using the binary format.
;	Step through your code one line at a time in debug mode.


	

; TASK 2:
;	Load registers 1-3 with the numbers 1 to 3.
;	Load registers 4-6 with the numbers -1 to -3
;	Load register 7 with the smallest unsigned number possible on this processor.
;	Load register 8 with the largest unsigned number possible on this processor.
;	Load register 9 with the largest signed number possible on this processor.
;	Load register 10 with the smallest signed number possible on this processor.
;	Step through your code one line at a time in debug mode.


	  
	  
; TASK 3:	 
;	Copy the value in R1 to R2.
;	Copy the value in R3 to R8.
;	Swap the values in R4 and R10. (Do not alter any data in R1-12)
	    

	  
	  
	  
	  
	  
    ALIGN        ; make sure the end of this section is aligned
    END          ; end of file
          