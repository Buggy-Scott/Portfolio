;****************** main.s ***************
; Program written by:  Dr. D
; Date Created: 10/10/2022
; Last Modified: 
; Brief description of the program: Demo code for conditional branching.
;	

; ********************************************************************************************
; ********************************************************************************************
;
;									ASSOCIATED VIDEOS
;
;		ECE_3436_Branching.mp4
;		ECE_3436_Branching_Code.mp4
;
; ********************************************************************************************
; ********************************************************************************************		  

	   THUMB
		   
 
; *********************************************************************
; ************************* ROM CONSTANTS AREA ************************
; *********************************************************************
; Constants and code area starts at address 0x0000.0000
	AREA    MyConstants, DATA, READONLY, ALIGN=2		; Flash EEPROM

myConst1	DCD		0xFFFFFFFF
constX		DCD		9
constY		DCD		0x80000000
	
constA		DCB		0xFF
	ALIGN
constB		DCW		0x8000

		 
		 
; *********************************************************************
; ************************* RAM VARIABLES AREA ************************
; *********************************************************************
; SRAM variables area starts at address 0x2000.0000
	AREA    MyVariables, DATA, READWRITE, ALIGN=2		; SRAM

varZ		SPACE	1
	
varC		SPACE	4

	ALIGN		  
		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
; EEROM --> code starts at address 0x0000.0284
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM
		  
		  
	ALIGN
		  
	EXPORT  Start
		
	  
		  
		  
Start

; ****************************************************************************
; ******************************** MAIN PROGRAM ******************************
; ****************************************************************************

; ******************** Unconditional Branch Example ********************


Top	
	MOV	R0, #-1
	B	skipit
	MOV	R1, #1	; these MOVs will NEVER execute!
	MOV	R2, #2	
	MOV R3, #3
	MOV	R4, #4
	MOV	R5, #5
	

	NOP
	


; ****************************************************************************
; ******************** Conditional Branch Example: Z Flag ********************


	; Clear condition flags
	MOV	R0, #0
	ADDS R0, R0, #1
	
	; Reset R1-R5 to 0
	MOV	R1, #0	
	MOV	R2, #0	
	MOV R3, #0
	MOV	R4, #0
	MOV	R5, #0
	


; ***** EXAMPLE: Add 1 to myConst and jumpt to the label skipit if the result
;					of the operation is zero.

	LDR R1, =myConst1
	LDR R0, [R1]
	
	; Compare R0 to zero
	;	What condition flag tells you if R0 is zero?
	;	How do know if CMP updates flags and which ones?
	;		Goto documentation to see! Two great places to check.
	;			ARM web site
	;			ARM Reference Manual
	CMP	R0, #0		; compare instruction ALWAYS updates the condition flags
	BEQ	skipit
	MOV	R1, #1	
	MOV	R2, #2	
	MOV R3, #3
	MOV	R4, #4
	MOV	R5, #5
	

	NOP
	
	
	
; *****************************************************************************
; ******************** Conditional Branch Example : C Flag ********************


	; Clear condition flags
	MOV	R0, #0
	ADDS R0, R0, #1
	
	; Reset R1-R5 to 0
	MOV	R1, #0	
	MOV	R2, #0	
	MOV R3, #0
	MOV	R4, #0
	MOV	R5, #0
	

; ***** EXAMPLE: Add 1 to myConst and jump to the label skipit if the operation does NOT cause
;				an unsigned overflow (i.e., the result is correct).

	LDR R1, =myConst1
	LDR R0, [R1]
	
	; ADD 1 to R0 and update flags
	; 	Can ADD update flags?
	;	Goto documentation to see! 
	ADDS R0, R0, #0x1
	BCC	skipit
	MOV	R1, #1	
	MOV	R2, #2	
	MOV R3, #3
	MOV	R4, #4
	MOV	R5, #5
	

	NOP
	


; ****************************************************************************
; ******************** Conditional Branch Example: N Flag ********************


	; Clear condition flags
	MOV	R0, #0
	ADDS R0, R0, #1
	
	; Reset R1-R5 to 0
	MOV	R1, #0	
	MOV	R2, #0	
	MOV R3, #0
	MOV	R4, #0
	MOV	R5, #0
	

; ***** EXAMPLE: Shift R0 to the left twice and jump to the label skipit if the
;					result is negative.

	MOV32	R0, #0xABCD1234
	LDR		R1, =0xFEDC9876
	LSLS	R0, #2			; result is 0xAF3448D0
	LSLS	R1, #2
	BMI		skipit
	MOV	R1, #1	
	MOV	R2, #2	
	MOV R3, #3
	MOV	R4, #4
	MOV	R5, #5
	

	NOP
	


; ****************************************************************************
; ******************** Conditional Branch Example; V Flag ********************	

	
	; Clear condition flags
	MOV	R0, #0
	ADDS R0, R0, #1
	
	; Reset R1-R5 to 0
	MOV	R1, #0	
	MOV	R2, #0	
	MOV R3, #0
	MOV	R4, #0
	MOV	R5, #0
	
	
; ***** EXAMPLE: Subtract 1 from R0 and jump to the label skipit if the
;					result causes a signed overflow (i.e., the result is wrong).

	MOV32	R0, #0x80000000	; smallest negative # with 32 bits
	SUBS	R0, R0, #1		; try to subtract 1  --> causes overflow
	BVS		skipit
	MOV	R1, #1	
	MOV	R2, #2	
	MOV R3, #3
	MOV	R4, #4
	MOV	R5, #5
	





skipit
	NOP




; ********************************************************************************************
; ********************************************************************************************
;
;									VIDEOS END HERE 
;
; ********************************************************************************************
; ********************************************************************************************







; *******************************************************
; ******************** MORE PRACTICE ********************

; x 	--> constX = 0 (32 bits)
; y		--> constY = 0x8000.0000 (32 bits)
; z		--> varZ (8 bits)


; *********************************************************************************
; TASK 1: Write the assembly equivalent code for the following MATLAB instruction.
;	if (constX==0) 
;		varZ = 1;
;	end

	; Reset condition flags
	MOV	R0, #0
	ADDS R0, R0, #1
	
task1
	; load the value of x into R0


	; compare the value of x to 0

	
	; if x is equal to 0 then set z equal 1


	
	NOP
	
; *********************************************************************************
; TASK 2: Write the assembly equivalent code for the following MATLAB instruction.
; 	if (constY~=4)
;		varZ = 2
; 	end

	; Clear condition flags
	MOV	R0, #0
	ADDS R0, R0, #1
	
task2	
	; load the value of y

	
	; compare the value to 4


	; if x is not equal to 4 then set z equal to 2

	
	
; *********************************************************************************
; TASK 3: Write the assembly equivalent code for the following MATLAB instruction.
;	if (constY>=7)
;		varZ = 3;
;	end
;
; *** assume UNSIGNED numbers

	; Clear condition flags
	MOV	R0, #0
	ADDS R0, R0, #1
	
task3

	
	
; *********************************************************************************
; TASK 4: Write the assembly equivalent code for the following MATLAB instruction.
;	if (constY<1)
;		varZ = 4;
;	end
;
; *** assume SIGNED numbers (two's complement)

	; Clear condition flags
	MOV	R0, #0
	ADDS R0, R0, #1
	
task4


; *********************************************************************************
; TASK 5: Write the assembly equivalent code for the following MATLAB instruction.
;	if (constY<1)
;		varZ = 4;
;	end
;
; *** assume UNSIGNED numbers 

	; Clear condition flags
	MOV	R0, #0
	ADDS R0, R0, #1
	
task5








; **** The following tasks require additional files for configuring and
;		using Port F. *****

; ********************************************************
; TASK 6: 	Turn only the red LED on when SW1 is pressed.


; *********************************************************
; TASK 7: 	Turn only the blue LED on when SW2 is pressed.


; **********************************************************************
; TASK 8: 	Turn only the green LED on when both SW1 & SW2 are pressed.


; **********************************************************************
; TASK 9: 	Combine Tasks 6-8.


      
    ALIGN      ; make sure the end of this section is aligned
    END        ; end of file

